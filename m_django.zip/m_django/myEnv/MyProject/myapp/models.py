from django.db import models

# Create your models here.
class shoes(models.Model):
    prodeuctname=models.CharField(max_length=100)
    brand=models.CharField(max_length=100)
    color=models.CharField(max_length=100)
    size=models.IntegerField()
    material=models.CharField(max_length=100)
    price=models.FloatField()
    stock=models.CharField(max_length=100)
    description=models.TextField()
    img=models.ImageField(upload_to='media/',default='image.jpg')
    date=models.DateField()
   

    def __str__(self):
        return self.prodeuctname
    
