from django.shortcuts import render,redirect
from .models import *
from datetime import date
# Create your views here.
def Index(request):
    s=shoes.objects.all()
    return render(request,"index.html",{'s':s})

def add(request):
    pname=request.POST.get("p_name")
    brand=request.POST.get("brand")
    color=request.POST.get("color")
    size=request.POST.get("size")
    material=request.POST.get("material")
    price=request.POST.get("price")
    stocks=request.POST.get("stocks")
    desc=request.POST.get("desc")
    date1=date.today()
    img=request.FILES['img']
    shoes.objects.create(prodeuctname=pname,brand=brand,color=color,size=size,material=material,price=price,stock=stocks,description=desc,img=img,date=date1)
    return redirect("index")

def update(request,id):
       pname=request.POST.get("p_name")
       brand=request.POST.get("brand")
       color=request.POST.get("color")
       size=request.POST.get("size")
       material=request.POST.get("material")
       price=request.POST.get("price")
       stocks=request.POST.get("stocks")
       desc=request.POST.get("desc")
       img=request.FILES['img']
       date1=date.today()
       s=shoes(
          id=id,
          prodeuctname=pname,brand=brand,color=color,size=size,material=material,price=price,stock=stocks,description=desc,img=img,date=date1
       )
       s.save()
       return redirect("index")

def delete(request,id):
     s=shoes.objects.filter(id=id)
     s.delete()
     return redirect("index")